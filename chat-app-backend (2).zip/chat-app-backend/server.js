const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const cors = require("cors");

const app = express();
app.use(cors());

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "http://localhost:3000",
    methods: ["GET", "POST"],
  },
});

let users = {};
let messages = [];

io.on("connection", (socket) => {
  console.log("New user connected:", socket.id);

  // User join with username
  socket.on("join", (username) => {
    users[socket.id] = username;
    io.emit("user-list", Object.values(users));
  });

  // Handle messages
  socket.on("chat message", (data) => { 
    const messageData = {
      id: socket.id,
      username: users[socket.id] || "Anonymous",
      text: data.text,
      time: new Date().toLocaleTimeString(),
    };
    messages.push(messageData);
    io.emit("chat message", messageData);
  });

  socket.on("join", (username) => {
    users[socket.id] = username;
    console.log("🔹 Current Users:", users);
    io.emit("user-list", Object.values(users)); 
  });
  
  socket.on("message", (data) => {
    const messageData = {
      id: socket.id,
      username: users[socket.id] || "Anonymous",
      text: data.text,
      time: new Date().toLocaleTimeString(),
    };
    io.emit("message", messageData);
  });
  

  // Edit message
  socket.on("edit message", ({ index, text }) => {
    if (messages[index]) {
      messages[index].text = text;
      io.emit("chat update", messages);
    }
  });

  // Delete message
  socket.on("delete message", (index) => {
    if (messages[index]) {
      messages.splice(index, 1);
      io.emit("chat update", messages);
    }
  });

  // Handle disconnect
  socket.on("disconnect", () => {
    delete users[socket.id];
    io.emit("user-list", Object.values(users));
    console.log("User disconnected:", socket.id);
  });
});

server.listen(5000, () => {
  console.log("Server running on port 5000");
});
